const Farmers = () => {
  return (
    <div>
      Farmers
    </div>
  )
}
export default Farmers;