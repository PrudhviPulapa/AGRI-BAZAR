import { useContext, useEffect, useState } from "react";
import { ContractContext } from "../../Services/Contexts/ContractContext";
import '../../Assests/Styles/verify.page.css';
import FarmerCard from "../../Components/Cards/FarmerCard";

const VerifyFarmer = () => {
  const {contractState} = useContext(ContractContext);
  const [addresses, setAddresses] = useState([]);
  useEffect(() => {
    (async() => {
      if(contractState.farmerContract){
        console.log("farmerContract getAddreses:"+ (await contractState.farmerContract.methods.getAddresses().call()));
        setAddresses(await contractState.farmerContract.methods.getAddresses().call());
      }
    })();
  }, [contractState.farmerContract])
  return (
    <div className="verify">
      <div align="center" className="h2 bg-warning rounded-pill" style={{fontWeight: 'bold'}}>Verify FPO</div>
      <div className="row">
        {addresses.map(address => (
          <FarmerCard id = {address} />
        ))}
      </div>
    </div>
  )
}
export default VerifyFarmer;