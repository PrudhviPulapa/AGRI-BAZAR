const Manufacturers = () => {
  return (
    <div>
      Corporate Consumer
    </div>
  )
}
export default Manufacturers;