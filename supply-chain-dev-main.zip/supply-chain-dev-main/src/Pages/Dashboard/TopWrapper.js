import img_cover from '../../Assests/Images/dashboard/top_wrapper.jpg';
import img_bgcover from '../../Assests/Images/Manufacturing_Blue.jpg';

const TopWrapper  = () => {
  return (
    <div className="top-wrapper">
      <div className="row d-flex justify-content-between">
        <div className="col-12 col-md-6">
          <img src={img_cover} width="105%"/>
        </div>
        <div class="has-bg-img" className="col-12 col-md-6" style={{backgroundColor: '',width:"48%",marginRight:14}}>
          <div className="tw-about text-center" >
            <p className="tw-heading fa-4x">Smart Agri Bazaar</p>
            <p className="tw-heading fa-2x">Trust  &gt;&gt;  Deal  &gt;&gt;  Delivered</p>
            <br /><br />
            <p className="tw-sub-heading fa-2x">
              We are aggregation ecosystem for farm produce and connect between the points of Origin, Consumption and Financial.<br/><br/><br/>
            </p><br /><br /><br /><br /><br />
          </div>
          <img class="bg-img" src={img_bgcover} width="103%" height="100%" style={{marginTop:-600,marginLeft:-4}}></img>
        </div>
      </div>
      <hr/>
    </div>
  ) 
}
export default TopWrapper;