import Routes from "../../Routes";

const Main  = () => {
  return (
    <div className="container">
      <Routes/>
    </div>
  )
}
export default Main;